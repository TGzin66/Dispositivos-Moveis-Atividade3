import React, { useState } from "react";
import { View, Text, TextInput, Button, FlatList, StyleSheet, Image } from "react-native";
import Item from "../models/Item";
import useItemViewModel from "../viewmodels/ItemViewModel";

export default function ItemView() {

  const { itens, adicionarItem } = useItemViewModel();

  const [nome, setNome] = useState<string>("");
  const [desc, setDesc] = useState<string>("");
  const [imagem, setImagem] = useState<string>("");

  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Catálogo de Itens</Text>

      <TextInput
        placeholder="Nome do item"
        value={nome}
        onChangeText={setNome}
        style={styles.input}
      />

      <TextInput
        placeholder="Descrição"
        value={desc}
        onChangeText={setDesc}
        style={styles.input}
      />

      <TextInput
        placeholder="URL da imagem"
        value={imagem}
        onChangeText={setImagem}
        style={styles.input}
      />

      <Button
        title="Adicionar"
        onPress={() => {
          adicionarItem(nome, desc, imagem);
          setNome("");
          setDesc("");
          setImagem("");
        }}
      />

      <FlatList
        data={itens}
        keyExtractor={(item: Item) => item.id}
        renderItem={({ item }: { item: Item }) => (
          <View style={styles.item}>

            <Image
              source={{ uri: item.imagem }}
              style={styles.imagem}
            />

            <View>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text>{item.desc}</Text>
            </View>

          </View>
        )}
      />

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    padding: 20
  },

  titulo: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15
  },

  input: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 10
  },

  item: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 1,
    alignItems: "center"
  },

  imagem: {
    width: 80,
    height: 80,
    marginRight: 10,
    borderRadius: 10
  },

  nome: {
    fontWeight: "bold",
    fontSize: 16
  }

});