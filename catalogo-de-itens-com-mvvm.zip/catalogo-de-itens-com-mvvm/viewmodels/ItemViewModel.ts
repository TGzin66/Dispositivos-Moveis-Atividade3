import { useState } from "react";
import Item from "../models/Item";
import ItemService from "../services/ItemService";

export default function useItemViewModel() {

  const [itens, setItens] = useState<Item[]>([
    new Item(
      "1",
      "Telefone",
      "Iphone 2077",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbsCHqW3REktAv8VonkuShF7wgF5eOrLhPfQ&s"
    ),
    new Item(
      "2",
      "Notebook",
      "Com Pincel Jaspion de 20° geração",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYun2iiUyqhsaIvySsl99RzNQ2LFPpSXfIlw&s"
    ),
    new Item(
      "3",
      "Smartwatch",
      "Não mostra as horas",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVszJNL7Q9D7MgNYSeB463JMPnvAhmmgJXSQ&s"
    )
  ]);

  function adicionarItem(nome: string, desc: string, imagem: string): void {

    const erro = ItemService.validarNome(nome, itens);

    if (erro) {
      alert(erro);
      return;
    }

    const novoItem = new Item(
      Date.now().toString(),
      nome,
      desc,
      imagem
    );

    setItens([...itens, novoItem]);
  }

  return {
    itens,
    adicionarItem
  };
}